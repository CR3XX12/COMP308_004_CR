import React from 'react'
import ReactDOM from 'react-dom/client'
//import App from './App.jsx'
import './index.css'
//
//import App from './App';
//import App from'./FunctNameFormApp';
//import App from './NameForm';
//import App from './FlavorForm';
//import App from './FunctFlavorFormApp';
//import App from './Reservation';
//import App from './FunctReservationFormApp';
//import App from'./FunctLoginForm'

//import App from './BasicRoutingTest';
//import App from './DynamicRoutingExample';
//import App from './NestedRoutingExample';
//import App from './ProtectedRoutesExample';
//import App from './TernaryStatementTest'
//import App from './BasicRoutingExample';
//import App from './LiftStateUp1'
//import App from './LiftStateUp2'
import App from './LiftStateUp3'
//import App from './ContactForm'

//import App from './NavigationWithRouterExample'


//
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
